import { Coffee, Star, MapPin } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-amber-50">
      <header className="p-8 bg-amber-900 text-white">
        <h1 className="text-4xl font-bold flex items-center gap-3">
          <Coffee size={36} />
          Artisan Coffee Shop
        </h1>
      </header>
      <main className="p-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
            <Star className="text-amber-600" />
            Our Specialty
          </h2>
          <p className="text-gray-700 mb-6">Experience the finest coffee in town.</p>
          <div className="flex items-center gap-2 text-amber-800">
            <MapPin />
            <span>123 Coffee Lane</span>
          </div>
        </div>
      </main>
    </div>
  );
}